import React, {
  useState,
  useEffect,
  useRef,
  useMemo,
  useCallback,
} from "react";
import * as d3 from "d3";
import axios from "axios";
import "../styles/CareerTracker.css";
import Navbar from "./Navbar";
import Footer from "./Footer";
import ScrollToTop from "./ScrollToTop";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import Loader from "./Loader";
const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const CareerTracker = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [inputs, setInputs] = useState({
    currentSkills: [],
    careerGoal: "",
    hoursPerWeek: "10-20",
    careerStage: "",
    educationLevel: "",
    currentlyStudying: "No",
    graduationYear: "",
    major: "",
    workExperience: "",
    previousIndustry: "",
    previousRole: "",
    currentCompany: "",
    currentRole: "",
    yearsOfExperience: "",
    internshipExperience: "",
    jobSearchStatus: "",
    currentIndustry: "",
    promotionTimeframe: "",
    switchReason: "",
    techEducation: "",
    goalTimeframe: "",
    learningPreference: "",
  });
  const [skillInput, setSkillInput] = useState("");
  const [careerPath, setCareerPath] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const svgRef = useRef(null);
  const [usageData, setUsageData] = useState({
    usageCount: 0,
    remainingCount: 3,
  });
  const [isLoadingUsage, setIsLoadingUsage] = useState(false);
  const navigate = useNavigate();
  const { token } = useSelector((state) => state.auth);
  const isAuthenticated = !!token;
  const getCareerStageQuestions = useMemo(() => {
    if (!inputs.careerStage) return [];

    switch (inputs.careerStage) {
      case "Student":
        return [
          {
            id: "educationLevel",
            question: "What is your current education level?",
            type: "select",
            options: [
              "High School",
              "Associate's Degree (In Progress)",
              "Bachelor's Degree (In Progress)",
              "Master's Degree (In Progress)",
              "PhD (In Progress)",
            ],
            placeholder: "Select your current education level",
          },
          {
            id: "major",
            question: "What is your major or field of study?",
            type: "text",
            placeholder: "E.g. Computer Science, Business",
          },
          {
            id: "graduationYear",
            question: "What year do you expect to graduate?",
            type: "select",
            options: ["2025", "2026", "2027", "2028", "2029", "Other"],
            placeholder: "Select your expected graduation year",
          },
          {
            id: "currentlyStudying",
            question:
              "Are you currently taking any courses relevant to your career goal?",
            type: "select",
            options: [
              "Yes, formal university courses",
              "Yes, online courses/bootcamps",
              "No",
            ],
            placeholder: "Select an option",
          },
          {
            id: "internshipExperience",
            question:
              "Do you have any internship or work experience related to tech?",
            type: "select",
            options: [
              "None",
              "1 internship",
              "2+ internships",
              "Part-time job experience",
            ],
            placeholder: "Select your experience level",
          },
        ];
      case "Recent Graduate":
        return [
          {
            id: "educationLevel",
            question: "What is your highest level of education completed?",
            type: "select",
            options: [
              "Associate's Degree",
              "Bachelor's Degree",
              "Master's Degree",
              "PhD",
              "Bootcamp",
              "Self-taught",
            ],
            placeholder: "Select your education level",
          },
          {
            id: "major",
            question: "What was your major or field of study?",
            type: "text",
            placeholder: "E.g. Computer Science, Business",
          },
          {
            id: "graduationYear",
            question: "When did you graduate?",
            type: "select",
            options: ["2024", "2023", "2022", "2021", "2020", "Earlier"],
            placeholder: "Select your graduation year",
          },
          {
            id: "jobSearchStatus",
            question: "What is your current job search status?",
            type: "select",
            options: [
              "Actively looking for first job",
              "Received offers, deciding",
              "Working first job but looking to switch",
              "Not actively looking yet",
            ],
            placeholder: "Select your job search status",
          },
          {
            id: "internshipExperience",
            question: "Did you complete any internships during your studies?",
            type: "select",
            options: [
              "None",
              "1 internship",
              "2+ internships",
              "Had part-time tech job",
            ],
            placeholder: "Select your experience level",
          },
        ];
      case "Working Professional":
        return [
          {
            id: "educationLevel",
            question: "What is your highest level of education completed?",
            type: "select",
            options: [
              "High School",
              "Associate's Degree",
              "Bachelor's Degree",
              "Master's Degree",
              "PhD",
              "Bootcamp",
              "Self-taught",
            ],
            placeholder: "Select your education level",
          },
          {
            id: "currentCompany",
            question: "What company do you currently work for?",
            type: "text",
            placeholder: "E.g. Google, Amazon",
          },
          {
            id: "currentRole",
            question: "What is your current job title?",
            type: "text",
            placeholder: "E.g. Software Engineer, Project Manager",
          },
          {
            id: "yearsOfExperience",
            question: "How many years of experience do you have in your field?",
            type: "select",
            options: [
              "Less than 1 year",
              "1-2 years",
              "3-5 years",
              "5-10 years",
              "10+ years",
            ],
            placeholder: "Select your experience range",
          },
          {
            id: "currentIndustry",
            question: "What industry are you currently working in?",
            type: "select",
            options: [
              "Tech/Software",
              "Finance/Banking",
              "Healthcare/Medical",
              "Education",
              "E-commerce/Retail",
              "Manufacturing",
              "Government",
              "Entertainment/Media",
              "Other",
            ],
            placeholder: "Select your current industry",
          },
          {
            id: "promotionTimeframe",
            question:
              "Are you looking for a promotion, lateral move, or complete career change?",
            type: "select",
            options: ["Promotion", "Lateral move", "Complete career change"],
            placeholder: "Select your career move type",
          },
        ];
      case "Career Switcher":
        return [
          {
            id: "educationLevel",
            question: "What is your highest level of education completed?",
            type: "select",
            options: [
              "High School",
              "Associate's Degree",
              "Bachelor's Degree",
              "Master's Degree",
              "PhD",
              "Other",
            ],
            placeholder: "Select your education level",
          },
          {
            id: "previousIndustry",
            question: "What industry are you transitioning from?",
            type: "select",
            options: [
              "Finance/Banking",
              "Healthcare/Medical",
              "Education",
              "Retail/Sales",
              "Manufacturing",
              "Government",
              "Entertainment/Media",
              "Hospitality/Service",
              "Other",
            ],
            placeholder: "Select your previous industry",
          },
          {
            id: "previousRole",
            question: "What was your previous job title?",
            type: "text",
            placeholder: "E.g. Accountant, Teacher",
          },
          {
            id: "workExperience",
            question: "How many years of work experience do you have?",
            type: "select",
            options: [
              "Less than 1 year",
              "1-2 years",
              "3-5 years",
              "5-10 years",
              "10+ years",
            ],
            placeholder: "Select your experience range",
          },
          {
            id: "switchReason",
            question: "What's your primary reason for switching to tech?",
            type: "select",
            options: [
              "Better career growth",
              "Higher salary potential",
              "Remote work opportunities",
              "Personal interest in technology",
              "Industry stability",
              "Other",
            ],
            placeholder: "Select your main motivation",
          },
          {
            id: "techEducation",
            question:
              "What tech education have you completed or are currently pursuing?",
            type: "select",
            options: [
              "None yet",
              "Self-taught/Online courses",
              "Bootcamp",
              "College courses",
              "Degree program",
              "Certification program",
            ],
            placeholder: "Select your tech education",
          },
        ];
      default:
        return [];
    }
  }, [inputs.careerStage]);
  const careerGoals = [
    "Full Stack Developer",
    "Frontend Developer",
    "Backend Developer",
    "DevOps Engineer",
    "Data Scientist",
    "Machine Learning Engineer",
    "Cloud Architect",
    "Mobile Developer",
    "UI/UX Designer",
    "Cybersecurity Specialist",
    "Blockchain Developer",
    "Game Developer",
    "AI Engineer",
    "System Administrator",
    "Product Manager",
    "CTO",
    "Tech Lead",
  ];

  const questions = useMemo(() => {
    // Initial basic questions that everyone answers first
    const initialQuestions = [
      {
        id: "careerStage",
        question: "What is your current career stage?",
        type: "select",
        options: [
          "Student",
          "Recent Graduate",
          "Working Professional",
          "Career Switcher",
        ],
        placeholder: "Select your career stage",
      },
    ];

    // Career stage specific questions (dynamically inserted based on career stage selection)
    const stageSpecificQuestions = inputs.careerStage
      ? getCareerStageQuestions
      : [];

    // Career goal and skills questions that everyone answers after the stage-specific ones
    const goalQuestions = [
      {
        id: "careerGoal",
        question: "What is your desired career or job title?",
        type: "select",
        options: careerGoals,
        placeholder: "Select a career goal",
      },
      {
        id: "goalTimeframe",
        question: "When do you hope to achieve this career goal?",
        type: "select",
        options: [
          "As soon as possible (< 1 year)",
          "Short-term (1-2 years)",
          "Medium-term (3-5 years)",
          "Long-term (5+ years)",
          "As Required",
        ],
        placeholder: "Select your goal timeframe",
      },
      {
        id: "currentSkills",
        question: "What are your current technical skills?",
        type: "skillsInput",
        placeholder: "E.g. Python, Photoshop, Excel",
      },
      {
        id: "hoursPerWeek",
        question:
          "How much time per week can you commit to learning or skill development?",
        type: "select",
        options: [
          "Less than 5 hours",
          "5-10 hours",
          "10-20 hours",
          "20+ hours",
        ],
        placeholder: "Select available time per week",
      },
      {
        id: "learningPreference",
        question: "What is your preferred learning style?",
        type: "select",
        options: [
          "Self-paced online courses",
          "Instructor-led courses",
          "Books and documentation",
          "Project-based learning",
          "Pair programming",
        ],
        placeholder: "Select your learning preference",
      },
    ];

    // Combine all questions in the correct order
    return [...initialQuestions, ...stageSpecificQuestions, ...goalQuestions];
  }, [inputs.careerStage, getCareerStageQuestions, careerGoals]);

  useEffect(() => {
    if (careerPath) {
      renderCareerPathVisualization();
    }
  }, [careerPath]);
  const handleGenerateRoadmapClick = () => {
    navigate("/generate-roadmap");
  };
  const handleSkillAdd = () => {
    if (
      skillInput.trim() &&
      !inputs.currentSkills.includes(skillInput.trim())
    ) {
      setInputs((prev) => ({
        ...prev,
        currentSkills: [...prev.currentSkills, skillInput.trim()],
      }));
      setSkillInput("");
    }
  };

  const handleSkillRemove = (skill) => {
    setInputs((prev) => ({
      ...prev,
      currentSkills: prev.currentSkills.filter((s) => s !== skill),
    }));
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    if (name === "careerStage" && value !== inputs.careerStage) {
      // Reset stage-specific fields
      setInputs((prev) => ({
        ...prev,
        [name]: value,
        educationLevel: "",
        major: "",
        graduationYear: "",
        currentlyStudying: "No",
        internshipExperience: "",
        jobSearchStatus: "",
        currentCompany: "",
        currentRole: "",
        yearsOfExperience: "",
        currentIndustry: "",
        promotionTimeframe: "",
        previousIndustry: "",
        previousRole: "",
        workExperience: "",
        switchReason: "",
        techEducation: "",
      }));
    } else {
      setInputs((prev) => ({
        ...prev,
        [name]: value,
      }));
    }
  };

  const handleNext = () => {
    const currentQuestion = questions[currentStep];
    if (
      currentQuestion.id === "currentSkills" &&
      inputs.currentSkills.length === 0
    ) {
      setError("Please add at least one skill");
      return;
    }
    if (currentQuestion.id === "careerGoal" && !inputs.careerGoal) {
      setError("Please select a career goal");
      return;
    }
    if (currentQuestion.id === "careerStage" && !inputs.careerStage) {
      setError("Please select a career stage");
      return;
    }
    if (currentQuestion.id === "educationLevel" && !inputs.educationLevel) {
      setError("Please select an education level");
      return;
    }
    setError(null);
    if (currentStep < questions.length - 1) {
      setCurrentStep((prev) => prev + 1);
      window.scrollTo(0, 0);
    } else {
      handleSubmit();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1);
      window.scrollTo(0, 0);
    }
  };
  const fetchUsageData = useCallback(async () => {
    if (!isAuthenticated) return;

    setIsLoadingUsage(true);
    try {
      const response = await axios.get(
        `${BACKEND_URL}/api/career-track/usage`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      setUsageData(response.data);
    } catch (error) {
      console.error("Error fetching career track usage:", error);
    } finally {
      setIsLoadingUsage(false);
    }
  }, [isAuthenticated, token]);

  useEffect(() => {
    fetchUsageData();
  }, [fetchUsageData]);

  const handleSubmit = async () => {
    if (!isAuthenticated) {
      setError("You must be logged in to use this feature");
      return;
    }

    if (inputs.currentSkills.length === 0) {
      setError("Please add at least one skill");
      return;
    }

    if (!inputs.careerGoal) {
      setError("Please select a career goal");
      return;
    }

    setLoading(true);
    setError(null);

    // Create a payload that includes all the basic fields plus any stage-specific fields that are populated
    const payload = { ...inputs };

    try {
      const response = await axios.post(
        `${BACKEND_URL}/api/career-track/simulate`,
        payload,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      setCareerPath(response.data.careerPath);
      setCurrentStep(questions.length); // Set to a step after the last question

      // Update usage data after successful submission
      fetchUsageData();
    } catch (err) {
      console.error("API Error:", err);
      setError(err.response?.data?.message || "Failed to generate career path");
    } finally {
      setLoading(false);
    }
  };

  const isQuestionAnswered = () => {
    const currentQuestion = questions[currentStep];
    if (!currentQuestion) return true;

    switch (currentQuestion.id) {
      case "careerGoal":
        return !!inputs.careerGoal;
      case "careerStage":
        return !!inputs.careerStage;
      case "educationLevel":
        return !!inputs.educationLevel;
      case "currentlyStudying":
        return !!inputs.currentlyStudying;
      case "currentSkills":
        return inputs.currentSkills.length > 0;
      case "hoursPerWeek":
        return !!inputs.hoursPerWeek;
      case "planningTimeframe":
        return !!inputs.planningTimeframe;
      default:
        return true;
    }
  };
  const renderCareerPathVisualization = () => {
    if (!svgRef.current || !careerPath) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    // Set fixed width and dimensions
    const width = 1200;
    const nodeRadius = 60;
    const basePadding = 150;
    const extraLabelPadding = 30;
    const rowHeight = 245;

    // Fixed number of nodes per row
    const maxNodesPerRow = 5;
    const numRows = Math.ceil(careerPath.length / maxNodesPerRow);
    const tooltipExtraSpace = 120;

    const height =
      numRows * rowHeight - (numRows > 1 ? 30 : 0) + tooltipExtraSpace;

    svg
      .attr("width", width)
      .attr("height", height)
      .attr("viewBox", `0 0 ${width} ${height}`)
      .attr("class", "career-track-svg")
      .attr("preserveAspectRatio", "xMidYMid meet");

    // Step 1: Calculate label sizes for spacing requirements
    const labelTexts = careerPath
      .slice(0, -1)
      .map((step) => `${step.timeToAchieve} months`);
    const dummyText = svg.append("text").attr("visibility", "hidden");
    const labelWidths = labelTexts.map((text) => {
      dummyText.text(text);
      return dummyText.node().getComputedTextLength() + extraLabelPadding;
    });
    dummyText.remove();

    // Step 2: Position the nodes with multi-row support
    const nodesWithPositions = [];
    let cumulativeTime = 0;

    careerPath.forEach((step, index) => {
      const prevTime = cumulativeTime;
      cumulativeTime += step.timeToAchieve;

      // Calculate which row and position within row
      const rowIndex = Math.floor(index / maxNodesPerRow);
      const positionInRow = index % maxNodesPerRow;

      // Calculate available width for nodes in this row
      const nodesInThisRow = Math.min(
        maxNodesPerRow,
        careerPath.length - rowIndex * maxNodesPerRow
      );
      const availableWidth = width - 2 * basePadding;
      const nodeSpacing = availableWidth / (nodesInThisRow - 1 || 1);

      // Calculate x position
      let x;
      if (nodesInThisRow === 1) {
        x = width / 2; // Center if only one node in row
      } else {
        x = basePadding + positionInRow * nodeSpacing;
      }

      // Calculate y position based on row
      const y = tooltipExtraSpace / 2 + rowHeight / 2 + rowIndex * rowHeight;

      nodesWithPositions.push({
        ...step,
        startTime: prevTime,
        endTime: cumulativeTime,
        x,
        y,
        progress: index / (careerPath.length - 1),
        rowIndex,
        positionInRow,
        monthLabel: `Month ${prevTime}`,
      });
    });

    const colorScale = d3
      .scaleLinear()
      .domain([0, 0.5, 1])
      .range(["#3498db", "#9b59b6", "#2ecc71"]);

    const pathGroup = svg.append("g").attr("class", "career-path-group");

    const defs = svg.append("defs");

    // Define a single static arrowhead for all lines
    defs
      .append("marker")
      .attr("id", "static-arrow")
      .attr("viewBox", "0 0 10 10")
      .attr("refX", 10)
      .attr("refY", 5)
      .attr("markerWidth", 10)
      .attr("markerHeight", 10)
      .attr("orient", "auto")
      .attr("markerUnits", "userSpaceOnUse")
      .append("path")
      .attr("d", "M 0 0 L 10 5 L 0 10 z")
      .attr("fill", "#fff");

    // Draw connection lines between nodes
    const paths = [];
    for (let i = 0; i < nodesWithPositions.length - 1; i++) {
      const start = nodesWithPositions[i];
      const end = nodesWithPositions[i + 1];

      let pathData;

      // Determine if we need a horizontal line or a connecting line between rows
      if (start.rowIndex === end.rowIndex) {
        // Same row - horizontal connection
        pathGroup
          .append("line")
          .attr("x1", start.x + nodeRadius)
          .attr("y1", start.y)
          .attr("x2", end.x - nodeRadius)
          .attr("y2", end.y)
          .attr("stroke", "#fff")
          .attr("stroke-width", 3)
          .attr("marker-end", "url(#static-arrow)")
          .attr("class", "career-path-line");

        pathData = {
          type: "horizontal",
          x1: start.x + nodeRadius,
          y1: start.y,
          x2: end.x - nodeRadius,
          y2: end.y,
          midX: (start.x + nodeRadius + end.x - nodeRadius) / 2,
          midY: start.y - 18,
        };
      } else {
        // Different rows - we need a path with clean 90-degree corners
        const horizontalExtension = 40;
        const verticalGap = rowHeight / 2;

        // Create the path with 90-degree corners and optimized vertical space
        const pathElement = pathGroup
          .append("path")
          .attr(
            "d",
            `M ${start.x + nodeRadius} ${start.y} 
           L ${start.x + nodeRadius + horizontalExtension} ${start.y}
           L ${start.x + nodeRadius + horizontalExtension} ${
              start.y + verticalGap
            }
           L ${end.x} ${start.y + verticalGap}
           L ${end.x} ${end.y - nodeRadius}`
          )
          .attr("fill", "none")
          .attr("stroke", "#fff")
          .attr("stroke-width", 3)
          .attr("marker-end", "url(#static-arrow)")
          .attr("class", "career-path-line between-rows");

        // Store path data for label positioning
        pathData = {
          type: "between-rows",
          startX: start.x + nodeRadius,
          startY: start.y,
          horizontalSegmentX: start.x + nodeRadius + horizontalExtension,
          horizontalSegmentY: start.y + verticalGap,
          endX: end.x,
          endY: end.y - nodeRadius,
          midX: (start.x + nodeRadius + horizontalExtension + end.x) / 2,
          midY: start.y + verticalGap,
        };
      }

      paths.push({
        start,
        end,
        pathData,
      });
    }

    // Labels between nodes with sufficient space - optimized positions
    paths.forEach((path, i) => {
      const { start, end, pathData } = path;
      const labelText = `${end.timeToAchieve} months`;

      // Calculate label width for background rect
      const tempText = svg
        .append("text")
        .text(labelText)
        .attr("visibility", "hidden");
      const actualLabelWidth = tempText.node().getComputedTextLength() + 20;
      tempText.remove();

      // Position the label appropriately based on whether nodes are on same row or different rows
      let labelX, labelY;

      if (pathData.type === "horizontal") {
        // Same row - place label in the middle of the horizontal line
        labelX = pathData.midX;
        labelY = pathData.midY;
      } else {
        // Different rows - place label on the horizontal part of the connecting path
        labelX = pathData.endX + 40; // Position to the left of the end node
        labelY = pathData.midY - 15; // Position above the horizontal segment, slightly closer
      }

      // Add label background with dynamic width
      pathGroup
        .append("rect")
        .attr("x", labelX - actualLabelWidth / 2)
        .attr("y", labelY - 17)
        .attr("width", actualLabelWidth)
        .attr("height", 24)
        .attr("rx", 12)
        .attr("ry", 12)
        .attr("fill", "#000")
        .attr("stroke", colorScale((start.progress + end.progress) / 2))
        .attr("stroke-width", 1)
        .attr("class", "timeline-label-bg");

      // Add label text
      pathGroup
        .append("text")
        .attr("x", labelX)
        .attr("y", labelY)
        .text(labelText)
        .attr("text-anchor", "middle")
        .attr("class", "timeline-label");
    });

    // Nodes and labels
    const nodeGroups = pathGroup
      .selectAll(".career-node")
      .data(nodesWithPositions)
      .enter()
      .append("g")
      .attr("class", "career-node")
      .attr("transform", (d) => `translate(${d.x}, ${d.y})`)
      .attr("data-month", (d) => d.startTime); // Add data attribute for month value

    // Add "Start" label to the first node
    const firstNode = nodesWithPositions[0];
    pathGroup
      .append("line")
      .attr("x1", firstNode.x)
      .attr("y1", firstNode.y - nodeRadius - 100)
      .attr("x2", firstNode.x)
      .attr("y2", firstNode.y - nodeRadius)
      .attr("stroke", "#fff")
      .attr("stroke-width", 3)
      .attr("opacity", 0.7)
      .attr("stroke-dasharray", "5,5");

    pathGroup
      .append("text")
      .attr("x", firstNode.x)
      .attr("y", firstNode.y - nodeRadius - 110)
      .text("Start")
      .attr("text-anchor", "middle")
      .attr("class", "path-endpoint-label")
      .attr("font-weight", "bold");

    // Add time label between Start and first node
    const firstNodeTime = firstNode.timeToAchieve;
    const firstTimeLabelText = `${firstNodeTime} months`;

    // Calculate label width for background rect
    const tempFirstText = svg
      .append("text")
      .text(firstTimeLabelText)
      .attr("visibility", "hidden");
    const firstLabelWidth = tempFirstText.node().getComputedTextLength() + 20;
    tempFirstText.remove();

    // Position label on the vertical line above the first node
    const firstLabelX = firstNode.x;
    const firstLabelY = firstNode.y - nodeRadius - 50;

    // Add label background
    pathGroup
      .append("rect")
      .attr("x", firstLabelX - firstLabelWidth / 2)
      .attr("y", firstLabelY - 17)
      .attr("width", firstLabelWidth)
      .attr("height", 24)
      .attr("rx", 12)
      .attr("ry", 12)
      .attr("fill", "#000")
      .attr("stroke", colorScale(0)) // First node color
      .attr("stroke-width", 1)
      .attr("class", "timeline-label-bg");

    // Add label text
    pathGroup
      .append("text")
      .attr("x", firstLabelX)
      .attr("y", firstLabelY)
      .text(firstTimeLabelText)
      .attr("text-anchor", "middle")
      .attr("class", "timeline-label");

    // Add "Keep Growing!" label to the last node
    const lastNode = nodesWithPositions[nodesWithPositions.length - 1];
    pathGroup
      .append("line")
      .attr("x1", lastNode.x)
      .attr("y1", lastNode.y + nodeRadius)
      .attr("x2", lastNode.x)
      .attr("y2", lastNode.y + nodeRadius + 60)
      .attr("stroke", "#fff")
      .attr("stroke-width", 3)
      .attr("opacity", 0.7)
      .attr("stroke-dasharray", "5,5");

    pathGroup
      .append("text")
      .attr("x", lastNode.x)
      .attr("y", lastNode.y + nodeRadius + 75)
      .text("Keep Growing!")
      .attr("text-anchor", "middle")
      .attr("class", "path-endpoint-label")
      .attr("font-weight", "bold");

    nodeGroups.each(function (d, i) {
      const node = d3.select(this);
      const gradientId = `node-gradient-${i}`;
      const nodeColor = colorScale(d.progress);
      const darkerNodeColor = d3.color(nodeColor).darker(0.5);

      // Radial gradient for node
      const radialGradient = defs
        .append("radialGradient")
        .attr("id", gradientId)
        .attr("cx", "50%")
        .attr("cy", "50%")
        .attr("r", "50%");

      radialGradient
        .append("stop")
        .attr("offset", "0%")
        .attr("stop-color", nodeColor);

      radialGradient
        .append("stop")
        .attr("offset", "100%")
        .attr("stop-color", darkerNodeColor);

      // Add node shadow
      node
        .append("circle")
        .attr("r", nodeRadius)
        .attr("fill", "rgba(0,0,0,0.2)")
        .attr("cx", 3)
        .attr("cy", 3)
        .attr("filter", "blur(3px)");

      // Main node circle with additional class for timeline interaction
      node
        .append("circle")
        .attr("r", nodeRadius)
        .attr("fill", `url(#${gradientId})`)
        .attr("stroke", darkerNodeColor)
        .attr("stroke-width", 2)
        .attr("class", "career-node-circle timeline-marker-point") // Add timeline-marker-point class for interaction
        .attr("data-index", i); // Add index for interaction
    });

    // Add node titles
    nodeGroups.each(function (d) {
      const node = d3.select(this);
      const words = d.title.split(" ");
      let lines = [],
        currentLine = "";

      words.forEach((word) => {
        const testLine = currentLine ? `${currentLine} ${word}` : word;
        if (testLine.length > 15 && currentLine) {
          lines.push(currentLine);
          currentLine = word;
        } else {
          currentLine = testLine;
        }
      });
      if (currentLine) lines.push(currentLine);

      lines.forEach((line, i) => {
        const lineHeight = 16;
        const yPos = (i - (lines.length - 1) / 2) * lineHeight;

        node
          .append("text")
          .text(line)
          .attr("text-anchor", "middle")
          .attr("y", yPos)
          .attr("class", "career-node-title")
          .attr("font-size", "12px")
          .attr("fill", "white");
      });

      // Add tooltip container for the node
      const tooltip = node
        .append("g")
        .attr("class", "node-tooltip")
        .style("opacity", 0)
        .attr("pointer-events", "none");

      // Calculate tooltip position above the node
      const tooltipY = -nodeRadius - 20;

      // Add tooltip background with rounded corners
      const tooltipText = d.description || "No description available";

      // Create temporary text to measure width
      const tempText = svg
        .append("text")
        .text(tooltipText)
        .attr("class", "tooltip-text-measure")
        .style("visibility", "hidden");

      // Get approximate text width & height for tooltip sizing
      const textWidth = Math.min(300, Math.max(200, tooltipText.length * 6));
      const textHeight = Math.ceil(tooltipText.length / 40) * 20 + 15;
      tempText.remove();

      tooltip
        .append("rect")
        .attr("x", -textWidth / 2)
        .attr("y", tooltipY - textHeight)
        .attr("width", textWidth)
        .attr("height", textHeight)
        .attr("rx", 8)
        .attr("ry", 8)
        .attr("class", "tooltip-bg");

      // Add tooltip text
      const tooltipTextElement = tooltip
        .append("text")
        .attr("x", 0)
        .attr("y", tooltipY - textHeight + 20)
        .attr("text-anchor", "middle")
        .attr("class", "tooltip-text");

      // Handle multi-line text in tooltip
      const tooltipLines = [];
      let tooltipCurrentLine = "";
      const maxCharsPerLine = 40;

      // Break description into multiple lines
      tooltipText.split(" ").forEach((word) => {
        if ((tooltipCurrentLine + " " + word).length > maxCharsPerLine) {
          tooltipLines.push(tooltipCurrentLine);
          tooltipCurrentLine = word;
        } else {
          tooltipCurrentLine = tooltipCurrentLine
            ? tooltipCurrentLine + " " + word
            : word;
        }
      });

      if (tooltipCurrentLine) {
        tooltipLines.push(tooltipCurrentLine);
      }

      // Add each line of text
      tooltipLines.forEach((line, i) => {
        tooltipTextElement
          .append("tspan")
          .text(line)
          .attr("x", 0)
          .attr("dy", i === 0 ? 0 : "1.2em");
      });

      // Add arrow at bottom of tooltip
      tooltip
        .append("path")
        .attr("d", `M -10 ${tooltipY} L 0 ${tooltipY + 10} L 10 ${tooltipY}`)
        .attr("class", "tooltip-arrow");
    });

    // Set up node interactions (combined timeline and node hover effects)
    setupNodeInteractions(nodeGroups);
  };

  const setupNodeInteractions = (nodeGroups) => {
    if (!nodeGroups) return;

    const nodeRadius = 60;

    // Add hover effects for tooltips
    nodeGroups.each(function () {
      const node = d3.select(this);
      const tooltip = node.select(".node-tooltip");

      // Show tooltip on hover
      node.on("mouseenter", function () {
        tooltip.transition().duration(200).style("opacity", 1);

        // Also highlight the node itself
        node
          .select(".career-node-circle")
          .transition()
          .duration(200)
          .attr("stroke-width", 4)
          .attr("r", nodeRadius * 1.1);
      });

      // Hide tooltip on mouse leave
      node.on("mouseleave", function () {
        tooltip.transition().duration(200).style("opacity", 0);

        // Reset node appearance
        node
          .select(".career-node-circle")
          .transition()
          .duration(200)
          .attr("stroke-width", 2)
          .attr("r", nodeRadius);
      });

      // Add click interaction to scroll to corresponding step card
      node.on("click", function () {
        const index = parseInt(
          node.select(".career-node-circle").attr("data-index"),
          10
        );

        // Find and scroll to corresponding step card
        const stepCards = document.querySelectorAll(".simulator-step-card");
        if (stepCards[index]) {
          stepCards[index].scrollIntoView({
            behavior: "smooth",
            block: "center",
          });

          // Add highlight effect
          stepCards[index].classList.add("highlighted-step");
          setTimeout(() => {
            stepCards[index].classList.remove("highlighted-step");
          }, 1500);
        }
      });
    });
  };

  const renderQuestionForm = () => {
    const currentQuestion = questions[currentStep];

    return (
      <div className="simulator-input-form">
        {renderUsageIndicator()}

        <div className="simulator-progress-bar">
          <div
            className="simulator-progress-fill"
            style={{
              width: `${((currentStep + 1) / questions.length) * 100}%`,
            }}
          ></div>
        </div>

        <div className="simulator-step-indicator">
          Question {currentStep + 1} of {questions.length}
        </div>

        <h2>{currentQuestion.question}</h2>
        {currentQuestion.type === "text" && (
          <div className="simulator-form-group">
            <input
              type="text"
              name={currentQuestion.id}
              value={inputs[currentQuestion.id]}
              onChange={handleInputChange}
              placeholder={currentQuestion.placeholder}
              className="simulator-input"
            />
          </div>
        )}
        {currentQuestion.type === "select" && (
          <div className="simulator-form-group">
            <div className="simulator-options-wrapper">
              {currentQuestion.id === "careerGoal" ? (
                <select
                  name={currentQuestion.id}
                  value={inputs[currentQuestion.id]}
                  onChange={handleInputChange}
                  className="simulator-select"
                >
                  <option value="">
                    {currentQuestion.placeholder || "Select an option"}
                  </option>
                  {currentQuestion.options.map((option) => (
                    <option key={option} value={option}>
                      {option}
                    </option>
                  ))}
                </select>
              ) : (
                currentQuestion.options.map((option) => (
                  <div
                    key={option}
                    className={`simulator-option ${
                      inputs[currentQuestion.id] === option
                        ? "simulator-selected"
                        : ""
                    }`}
                    onClick={() =>
                      handleInputChange({
                        target: { name: currentQuestion.id, value: option },
                      })
                    }
                  >
                    {option}
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {currentQuestion.type === "skillsInput" && (
          <div className="simulator-form-group">
            <div className="simulator-skills-input">
              <input
                type="text"
                value={skillInput}
                onChange={(e) => setSkillInput(e.target.value)}
                placeholder="Enter a skill and press Add"
                className="simulator-input"
              />
              <button
                onClick={handleSkillAdd}
                className="simulator-btn add-skill"
              >
                Add
              </button>
            </div>
            <div className="simulator-skills-list">
              {inputs.currentSkills.map((skill) => (
                <div key={skill} className="simulator-skill-tag">
                  {skill}
                  <span onClick={() => handleSkillRemove(skill)}>×</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="simulator-navigation">
          {currentStep > 0 && (
            <button
              className="simulator-secondary-btn"
              onClick={handlePrevious}
            >
              Previous
            </button>
          )}

          <button
            className="simulator-primary-btn"
            onClick={handleNext}
            disabled={!isQuestionAnswered()}
          >
            {currentStep < questions.length - 1
              ? "Next"
              : "Generate Career Path"}
          </button>
        </div>
      </div>
    );
  };
  const renderUsageIndicator = () => {
    if (!isAuthenticated) return null;

    return (
      <div className="usage-indicator">
        <span className="usage-count">
          {isLoadingUsage
            ? "Loading..."
            : `${usageData.usageCount}/3 usages today`}
        </span>
      </div>
    );
  };
  const renderCareerSummary = () => {
    if (!careerPath) return null;

    // Calculate total months to reach goal
    const totalMonths = careerPath.reduce(
      (sum, step) => sum + step.timeToAchieve,
      0
    );

    // Convert to years and months
    const years = Math.floor(totalMonths / 12);
    const months = totalMonths % 12;

    // Get first and last step titles for the journey summary
    const startPosition = careerPath[0].title;
    const endPosition = careerPath[careerPath.length - 1].title;

    // Get all unique skills needed throughout the journey
    const allSkills = new Set();
    careerPath.forEach((step) => {
      step.requiredSkills.forEach((skill) => allSkills.add(skill));
    });

    // Count how many skills the user already has
    const currentSkillsSet = new Set(
      inputs.currentSkills.map((skill) => skill.toLowerCase())
    );
    const skillsToLearn = [...allSkills].filter(
      (skill) =>
        !Array.from(currentSkillsSet).some(
          (userSkill) =>
            skill.toLowerCase().includes(userSkill) ||
            userSkill.includes(skill.toLowerCase())
        )
    );

    const timelineSegments = [];
    let cumulativeTime = 0;
    careerPath.forEach((step, index) => {
      // First, add the time to achieve
      cumulativeTime += step.timeToAchieve;

      // Then use that time as the starting point for this milestone
      timelineSegments.push({
        title: step.title,
        startMonth: cumulativeTime, // Now this represents the time to achieve this step
        endMonth: cumulativeTime,
        duration: step.timeToAchieve,
      });
    });

    return (
      <div className="career-summary-container">
        <h3>Career Journey Summary</h3>

        <div className="career-summary-stats">
          <div className="summary-stat">
            <span className="stat-label">Total Time to Goal</span>
            <span className="stat-value">
              {years > 0 ? `${years} year${years > 1 ? "s" : ""}` : ""}
              {months > 0
                ? `${years > 0 ? " and " : ""}${months} month${
                    months > 1 ? "s" : ""
                  }`
                : ""}
            </span>
          </div>

          <div className="summary-stat">
            <span className="stat-label">Journey</span>
            <span className="stat-value">
              {startPosition} → {endPosition}
            </span>
          </div>

          <div className="summary-stat">
            <span className="stat-label">Career Milestones</span>
            <span className="stat-value">{careerPath.length} steps</span>
          </div>

          <div className="summary-stat">
            <span className="stat-label">New Skills to Learn</span>
            <span className="stat-value">{skillsToLearn.length}</span>
          </div>
        </div>

        {/* Timeline Summary */}
        <div className="timeline-summary">
          <div className="timeline-milestones">
            {timelineSegments.map((segment, index) => (
              <div
                key={index}
                className="timeline-milestone-compact"
                onClick={() => scrollToStepCard(index)}
              >
                <div className="milestone-month">
                  Month {segment.startMonth}
                </div>
                <div className="milestone-marker"></div>
                <div className="milestone-title">{segment.title}</div>
              </div>
            ))}
            {/* Add final month marker */}
            <div className="timeline-milestone-compact final-milestone">
              <div className="milestone-month">Month {totalMonths}</div>
              <div className="milestone-marker"></div>
              <div className="milestone-title">Goal Reached</div>
            </div>
          </div>
        </div>

        <div className="career-advice-notes">
          <p>
            <strong>Notes:</strong> This career path is tailored for a{" "}
            {inputs.careerStage.toLowerCase()} with {inputs.educationLevel}{" "}
            education, committing {inputs.hoursPerWeek} weekly to skill
            development. The plan focuses on progression toward becoming a{" "}
            {inputs.careerGoal}.
          </p>
        </div>
      </div>
    );
  };

  const scrollToStepCard = (index) => {
    const stepCards = document.querySelectorAll(".simulator-step-card");
    if (stepCards[index]) {
      stepCards[index].scrollIntoView({
        behavior: "smooth",
        block: "center",
      });

      // Add highlight effect
      stepCards[index].classList.add("highlighted-step");
      setTimeout(() => {
        stepCards[index].classList.remove("highlighted-step");
      }, 1500);
    }
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="simulator-loading">
          <Loader loading={true} />
        </div>
      );
    }

    if (error) {
      return (
        <div className="simulator-error">
          <h3>{error}</h3>
          <button
            className="simulator-btn primary"
            onClick={() => setError(null)}
          >
            Try Again
          </button>
        </div>
      );
    }

    if (!isAuthenticated) {
      return (
        <div className="simulator-container simulator-auth-required">
          <h2>Authentication Required</h2>
          <p>You need to log in to use the Career Tracker feature.</p>
        </div>
      );
    }

    if (currentStep < questions.length) {
      return renderQuestionForm();
    }

    if (careerPath) {
      return (
        <div className="simulator-results">
          {renderUsageIndicator()}

          <h2>Your Career Path to {inputs.careerGoal}</h2>
          <p className="simulator-subtitle">
            Personalized plan based on your profile and goals
          </p>

          {renderCareerSummary()}

          <div className="simulator-visualization-container">
            <svg ref={svgRef} className="career-path-visualization"></svg>
          </div>
          {/* AI Feedback Section */}
          {careerPath.length > 0 && careerPath[0].aiFeedback && (
            <div className="simulator-ai-feedback">
              <h3>AI Career Coach Feedback</h3>
              <div className="simulator-ai-feedback-card">
                <div className="simulator-ai-icon">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 24 24"
                    fill="currentColor"
                    width="24"
                    height="24"
                  >
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z" />
                  </svg>
                </div>
                <div className="simulator-ai-feedback-content">
                  <p>{careerPath[0].aiFeedback}</p>
                </div>
              </div>
            </div>
          )}
          <div className="simulator-career-steps">
            <h3>Career Steps Breakdown</h3>
            <div className="simulator-steps-list">
              {careerPath.map((step, index) => {
                const prevStepTime =
                  index > 0
                    ? careerPath
                        .slice(0, index)
                        .reduce((sum, s) => sum + s.timeToAchieve, 0)
                    : 0;

                return (
                  <div key={index} className="simulator-step-card">
                    <div className="simulator-step-header">
                      <h4>{step.title}</h4>
                      <span className="simulator-timeframe">
                        {index === 0 ? "Start" : `+${prevStepTime} months`} →
                        {index === careerPath.length - 1
                          ? " Goal Reached!"
                          : ` +${prevStepTime + step.timeToAchieve} months`}
                      </span>
                    </div>
                    <p>{step.description}</p>
                    <div className="simulator-skills-required">
                      <h5>Required Skills:</h5>
                      <div className="simulator-skills-tags">
                        {step.requiredSkills.map((skill, i) => (
                          <span key={i} className="simulator-skill-badge">
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* New section for learning resources */}
                    {step.learningResources &&
                      step.learningResources.length > 0 && (
                        <div className="simulator-learning-resources">
                          <h5>Recommended Learning Resources:</h5>
                          <ul className="simulator-resources-list">
                            {step.learningResources.map((resource, i) => (
                              <li key={i}>{resource}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="simulator-action-buttons">
            <div className="ai-roadmap-wrapper">
              <p className="ai-roadmap-heading">
                Want to create AI roadmaps too?
              </p>
              <button
                className="simulator-btn secondary"
                onClick={handleGenerateRoadmapClick}
              >
                Generate AI Roadmap✨
              </button>
            </div>
            <button
              className="simulator-btn primary"
              onClick={() => {
                setCurrentStep(0);
                setCareerPath(null);
                window.scrollTo(0, 0);
              }}
            >
              Start Again
            </button>
          </div>
        </div>
      );
    }

    return null;
  };

  return (
    <div className="career-simulator-page full-page-layout">
      <Navbar />
      <div className="career-simulator-content">
        <div className="notifications-container">
          <div className="alert">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg
                  aria-hidden="true"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 alert-svg"
                >
                  <path
                    clipRule="evenodd"
                    d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                    fillRule="evenodd"
                  ></path>
                </svg>
              </div>
              <div className="alert-prompt-wrap">
                <p className="text-sm text-yellow-700">
                  These career path advices is AI-generated and has not been
                  reviewed for accuracy. Use it as a reference and verify
                  information from reliable sources.
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="career-simulator-container">{renderContent()}</div>
      </div>

      <ScrollToTop />
      <Footer />
    </div>
  );
};

export default CareerTracker;
